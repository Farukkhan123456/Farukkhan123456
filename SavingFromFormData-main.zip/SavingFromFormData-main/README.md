
 [![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=794EF7&random=false&width=435&lines=FORK+THIS+REPOSITORY+AND+USE+(FREE))](https://git.io/typing-svg) 

## `DECLAIMER`


[![MR INDIAN HACKER](https://i.ibb.co/vDwL05C/1716780350498.jpg)](https://youtube.com/@mrindianhelper_hacer)

<p align="center">
<a href="https://github.com/hackesofice"><img title="Author" src="https://img.shields.io/badge/CREATOR-HACKER-black.svg?style=for-the-badge&logo=github"></a>
 
<p style="color="blue"> this is an simple tool for fun by using this tool yow will be able to send messages, post comments continuously (nonstop) don't try to use it for taking revenge otherwise developer isn't responsible for any type of controversys, this tool contains a webview where you can see many options like-<br><br>
 1. Home (in developement),<br><br>
 2. Live Console, <br><br>
 3. Video Tab (Technology related videos<br><br>
 4. loader secton, <br><br>
 5. Notification (in development),<br><br>
 6. sidebar where we're trying to add
  more things in future </p>
<br><br>


📊 **TOOL INFO**
<p align="center">
<a href="https://github.com/hackesofice/followers"><img title="Followers" src="https://img.shields.io/github/followers/hackesofice?color=red&style=flat-square"></a>
<a href="https://github.com/hackesofice/SavingFromFormData/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/hackesofice/SavingFromFormData?color=blue&style=flat-square"></a>
<a href="https://github.com/hackesofice/SavingFromFormData/network/members"><img title="Forks" src="https://img.shields.io/github/forks/hackesofice/SavingFromFormData?color=red&style=flat-square"></a>
<a href="https://github.com/hackesofice/SavingFromFormData/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/hackesofice/SavingFromFormData?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/hackesofice/SavingFromFormData"><img title="Open Source" src="https://img.shields.io/badge/Author-MRINDIAN%20HACKER.-red?v=103"></a>
<a href="https://github.com/hackesofice/SavingFromFormData/"><img title="Size" src="https://img.shields.io/github/repo-size/hackesofice/SavingFromFormData?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fhackesofice%2FSavingFromFormData%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false"/></a>          
<a href="https://github.com/hackesofice/SavingFromFormData/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>



## `Installation Steps`

**STEP 1 ==> Click Bellow**<br>
<a href='https://github.com/hackesofice/SavingFromFormData/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=sky-blue'></a> 

**STEP 2 ==> CHOOSE DEPLOYMENT OPTION**
<p>Yau are able to deploy this tool in many platefors like- <br>1. REPLIT <br>2. RENDER <br> 3. KOYEB <br> 4. HEROKU <br>5. TERMUX <br>6. PC</p>

**DEPLOY ON TERMUX**

```
pkg install python -y
termux-setup-storage
pkg install git
cd /storage/emulated/0/
pkg update && pkg upgrade
rm -rf SavingFromFormData
git clone https://github.com/hackesofice/SavingFromFormData.git
cd SavingFromFormData
pip install -r requirements.txt
python main.py &
sleep 65
xdg-open http://localhost:5000
```


**DEPLOY ON PC**

```
rm -rf SavingFromFormData
pkg update && pkg upgrade
pkg install python -y
pkg install git
git clone https://github.com/hackesofice/SavingFromFormData.git
cd SavingFromFormData
pip install -r requirements.txt
start python main.py
timeout /t 65
start http://localhost:5000
```

